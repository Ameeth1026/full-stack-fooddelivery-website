import mongoose from 'mongoose'

export const connectDB = async ()=>{
    await mongoose.connect(`
        //add your monogdb address link
         `).then(()=>{
        console.log("DB CONNECTED")
    })
};



//mongodb+srv://<username>:<password>@cluster0.nzx1e.mongodb.net/<database name>


// important thing when your create a database in mongodb dont use '@ # $'

// use numbers and Character