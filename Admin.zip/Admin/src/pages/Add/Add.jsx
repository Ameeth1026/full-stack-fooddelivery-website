import React, { useState, useEffect } from 'react';
import './Add.css';
import { assets } from '../../assets/assets';
import axios from 'axios';
import { toast } from 'react-toastify';

const Add = ({url}) => {

  const [image, setImage] = useState(null);
  const [imageURL, setImageURL] = useState(null);
  const [data, setData] = useState({
    name: "",
    description: "",
    price: '',
    category: "Salad"
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData(prevData => ({
      ...prevData,
      [name]: name === 'price' ? Number(value) : value
    }));
  };

  const onsubmithandler = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("name", data.name);
    formData.append("description", data.description);
    formData.append("price", Number(data.price));
    formData.append("category", data.category);
    formData.append("image", image);

    const response = await axios.post(`${url}/api/food/add`, formData);

    if (response.data.success) {
      setData({
        name: "",
        description: "",
        price: '',
        category: "Salad"
      });
      setImage(null);        // Reset the image
      setImageURL(null);     // Reset the preview
      toast.success(response.data.message);
    } else {
      toast.error(response.data.message);
    }
  };

  useEffect(() => {
    if (image) {
      const newImageURL = URL.createObjectURL(image);
      setImageURL(newImageURL);
      return () => URL.revokeObjectURL(newImageURL);
    }
  }, [image]);

  return (
    <div className='add'>
      <form className="flex-col" onSubmit={onsubmithandler}>
        <div className="add-img-upload flex-col">
          <p>Upload Image</p>
          <label htmlFor="image">
            <img src={imageURL || assets.upload} alt="Upload Preview" />
          </label>
          <input 
            type="file" 
            id="image" 
            hidden 
            required 
            onChange={(e) => setImage(e.target.files[0])}
          />
        </div>

        <div className="add-product-name flex-col">
          <p>Product Name</p>
          <input 
            type="text" 
            placeholder="Type here" 
            name="name" 
            value={data.name} 
            onChange={handleChange} 
          />
        </div>

        <div className="add-product-description flex-col">
          <p>Description</p>
          <textarea 
            name="description" 
            rows="8" 
            placeholder="Write content here" 
            value={data.description} 
            onChange={handleChange} 
          />
        </div>

        <div className="add-category-price">
          <div className="add-category flex-col">
            <p>Product Category</p>
            <select name="category" value={data.category} onChange={handleChange}>
              <option value="Salad">Salad</option>
              <option value="Rolls">Rolls</option>
              <option value="Deserts">Deserts</option>
              <option value="SandWich">SandWich</option>
              <option value="Cake">Cake</option>
              <option value="Pure Veg">Pure Veg</option>
              <option value="Pasta">Pasta</option>
              <option value="Noodles">Noodles</option>
              <option value="Indian">Indian</option>
            </select>
          </div>

          <div className="add-price flex-col">
            <p>Product Price</p>
            <input 
              type="number" 
              placeholder="₹ 20" 
              name="price" 
              value={data.price} 
              onChange={handleChange} 
            />
          </div>
        </div>

        <button className='add-button' type='submit'>ADD</button>
      </form>
    </div>
  );
};

export default Add;
