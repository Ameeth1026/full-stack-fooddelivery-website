import React, { useEffect, useState } from "react";
import "./List.css";
import { toast } from "react-toastify";

import axios from "axios";

const List = ({url}) => {

  const [list, setList] = useState([]);

  const fetchlist = async () => {
    const response = await axios.get(`${url}/api/food/list`);
    if (response.data.success) {
      setList(response.data.data);
    } else {
      toast.error("Error");
    }
  };

  useEffect(() => {
    fetchlist();
  }, []);

  const removefood = async (foodid) => {
    const response = await axios.post(`${url}/api/food/remove`, { id: foodid });
    await fetchlist();

    if (response.data.success) {
      toast.success(response.data.message);
    } else {
      toast.error("Error");
    }
  };

  return (
    <div className="list add flex-col">
      <h1>all foods list</h1>
      <div className="list-table">
        <div className="list-table-format title">
          <b>image</b>
          <b>name</b>
          <b>category</b>
          <b>price</b>
          <b>action</b>
        </div>
        {list.map((item, index) => {
          return (
            <div className="list-table-format" key={index}>
              <div className="image_box">
                <img src={`${url}/images/` + item.image} alt="" />
              </div>
              <p>{item.name}</p>
              <p>{item.category}</p>
              <p>₹ {item.price}</p>
              <p
                onClick={() => {
                  removefood(item._id);
                }}
                className="remove_btn"
              >
                <button>x</button>
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default List;
