import React from 'react'
import './Order.css'

const Orders = () => {
  return (
    <div>Orders</div>
  )
}

export default Orders