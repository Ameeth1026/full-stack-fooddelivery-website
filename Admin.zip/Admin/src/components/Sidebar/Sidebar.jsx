import React from 'react';
import './Sidebar.css';
import { NavLink } from 'react-router-dom';

const Sidebar = () => {

  return (
    <div className='sidebar'>
      <div className="sidebar_options">
        <NavLink to='/add' className='sidebar_option'>
          <i className="fas fa-cart-plus"></i>
          <p>Add items</p>
        </NavLink>

        <NavLink to='/list' className='sidebar_option'>
          <i className="fas fa-list-check"></i>
          <p>List items</p>
        </NavLink>

        <NavLink to='/orders' className='sidebar_option'>
          <i className="fas fa-box-open"></i>
          <p>Orders</p>
        </NavLink>
      </div>
    </div>
  );
};

export default Sidebar;
