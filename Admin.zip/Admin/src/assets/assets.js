import logo from './logo.png'
import profile from './profile.png'
import upload from './upload.png'




export const assets = {
    logo,
    profile,
    upload,
}