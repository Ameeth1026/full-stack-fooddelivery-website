import axios from "axios";
import { createContext, useEffect, useState } from "react";

// Create a context to manage the store state
export const Store_Context = createContext(null);

const StoreContextProvider = (props) => {
  const [cartItems, setCartItems] = useState({}); // Object to hold items in the cart
  const [token, setToken] = useState(""); // To store authentication token
  const [food_list, setFoodList] = useState([]); // Array to hold the food items
  const url = "http://localhost:4000"; // Base URL for API requests

  // Function to add items to the cart
  const addToCart = async (itemId) => {
    setCartItems((prev) => {
      const updatedItems = { ...prev };
      updatedItems[itemId] = (updatedItems[itemId] || 0) + 1; // Increment item quantity
      console.log("Updated cartItems after add:", updatedItems); // Log the updated state
      return updatedItems;
    });

    if (token) {
      await axios.post(`${url}/api/cart/add`, { itemId }, { headers: { token } });
    }
  };

  // Function to remove items from the cart
  const removeFromCart = async (itemId) => {
    setCartItems((prev) => {
      const updatedItems = { ...prev };
      if (updatedItems[itemId] === 1) {
        delete updatedItems[itemId]; // Remove item if quantity is 1
      } else {
        updatedItems[itemId] -= 1; // Decrease quantity
      }
      return updatedItems;
    });

    if (token) {
      await axios.post(`${url}/api/cart/remove`, { itemId }, { headers: { token } });
    }
  };

  // Function to calculate the total amount of the items in the cart
  const getTotalCartAmount = () => {
    return Object.entries(cartItems).reduce((totalAmount, [item, quantity]) => {
      const itemInfo = food_list.find((product) => product._id === item);
      if (itemInfo) {
        totalAmount += itemInfo.price * quantity; // Calculate total price
      } else {
        console.warn(`Item with id ${item} not found in the food list.`);
      }
      return totalAmount;
    }, 0);
  };

  // Function to fetch the food list from the API
  const fetchFoodList = async () => {
    const response = await axios.get(`${url}/api/food/list`);
    setFoodList(response.data.data); // Update the food_list state with the fetched data
  };

  const loadCartData = async (token) => {
    const response = await axios.post(`${url}/api/cart/get`, {}, { headers: { token } });
    console.log("Cart data response:", response.data); // Log the response for debugging
    setCartItems(response.data.cartData || {}); // Ensure cartData is correctly set
  };

  useEffect(() => {
    const loadData = async () => {
      await fetchFoodList();
      const storedToken = localStorage.getItem("token");
      if (storedToken) {
        setToken(storedToken); // Set token
        await loadCartData(storedToken); // Load cart data based on token
      }
    };
    loadData();
  }, []);

  // Context value to be provided to children components
  const ContextValue = {
    food_list,
    cartItems,
    setCartItems,
    addToCart,
    removeFromCart,
    url,
    getTotalCartAmount,
    setToken,
    token,
  };

  return (
    <Store_Context.Provider value={ContextValue}>
      {props.children} {/* Render children components within the context provider */}
    </Store_Context.Provider>
  );
};

export default StoreContextProvider;
