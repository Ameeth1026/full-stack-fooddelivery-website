import React, { useContext } from 'react';
import './Cart.css';
import { Store_Context } from '../../context/Store_Context';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  // Use useContext to access Store_Context
  const { cartItems, food_list, removeFromCart, getTotalCartAmount, url } = useContext(Store_Context);
  const navigate = useNavigate();

  return (
    <div className='Cart'>
      <div className="cart_items">
        <div className="cart_item_title item_title">
          <p>Items</p>
          <p>Title</p>
          <p>Price</p>
          <p>Quantity</p>
          <p>Total</p>
          <p>Remove</p>
        </div>
        {food_list.map((item) => {
          // Ensure to use _id or the correct id in cartItems
          if (cartItems[item._id] > 0) {
            return (
              <div key={item._id} className='cart_box'>
                <div className="cart_items_item">
                  <div className="cart_item_title dd_items">
                    <p><img src={url+"/images/"+item.image} alt="" /></p>
                    <p>{item.name}</p>
                    <p>₹{item.price}</p>
                    <p>{cartItems[item._id]}</p>
                    <p>₹{item.price * cartItems[item._id]}</p>
                    <p className="center_item" onClick={() => removeFromCart(item._id)}>
                      <i className="fas fa-trash"></i>
                    </p>
                  </div>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>

      <div className="cart_down">
        <div className="cart_bottom">
          <div className="cart_total">
            <h2>Cart Totals</h2>
          </div>
          <div className="cart-total-details">
            <p>Subtotal</p>
            <p>₹{getTotalCartAmount()}</p>
          </div>
          <div className="cart-total-details border_top_bottom">
            <p>Delivery Fee</p>
            <p>₹{getTotalCartAmount() === 0 ? 0 : 2}</p>
          </div>
          <div className="cart-total-details">
            <p>Total</p>
            <p>₹{getTotalCartAmount() === 0 ? 0 : getTotalCartAmount() + 2}</p>
          </div>
          <button onClick={() => navigate('/order')}>Proceed to Checkout</button>
        </div>
        <div className="cart-promocode">
          <div>
            <h5>If you have a promo code, enter it here</h5>
            <div className="cart_promocode_input">
              <input type="text" placeholder='Promo Code' />
              <button>Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
