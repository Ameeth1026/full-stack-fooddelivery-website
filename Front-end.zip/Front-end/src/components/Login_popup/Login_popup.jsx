import React, { useContext, useState } from 'react'
import './Login_popup.css'
import {assets} from '../../assets/assets'
import { Store_Context } from '../../context/Store_Context'
import axios from 'axios'

const Login_popup = ({setShowLogin}) => {

  const {url,setToken} = useContext(Store_Context)

  const [currentstate,setCurrentstate] = useState("Login");
  const [data,setData] = useState({
    name:"",
    email:"",
    password:"",
  });

  const onChangeHandler = (event) =>{
    const name = event.target.name
    const value = event.target.value;
    setData(data=>({...data,[name]:value}))
  }

  const onLogin = async (event) =>{
    event.preventDefault()
    let newUrl = url;
    if (currentstate==="Login") {
      newUrl +="/api/user/login"
    }else{
      newUrl += "/api/user/register"
    }
    const response = await axios.post(newUrl,data);

    if (response.data.sucess) {
      setToken(response.data.token);
      localStorage.setItem("token",response.data.token);
      setShowLogin(false)
    }
    else{
      alert(response.data.message)
    }
  }

  return (
    <div className='login_popup'>

      <form onSubmit={onLogin} className="login_popup_container">

        <div className="login_popup_title">

          <h2>
            <img src={assets.logo} alt="" />
            {currentstate}
          </h2>
          <img onClick={()=>setShowLogin(false)} src={assets.cross_icon} alt="" />
        
        </div>

        <div className="login_popup_input">
          
          {currentstate==="Login"?<></>: 
          <div className="user_field">
            <i className="fas fa-user"></i>
            <input name='name' autoComplete='off' onChange={onChangeHandler} value={data.name} type="text" placeholder='Your Name'  required/>
          </div> }
            <div className="user_field">
            <i className="fas fa-envelope"></i>
          <input name='email' autoComplete='off' onChange={onChangeHandler} value={data.email} type="email" placeholder='Your Email'  required/>
            </div>
            <div className="user_field">
            <i className="fas fa-lock"></i>
          <input name='password' autoComplete='off' onChange={onChangeHandler} value={data.password} type="password" placeholder='Your Password'  required/>
            </div>

        </div>

        <button type='submit'>{currentstate==="Sign Up"?"Create Account":"Login"}</button>
        
        <div className="login_popup_condition">

          <input type="checkbox" name="" id="check" required />
          <p> i agree to the terms of use & privacy policy.</p>
       
        </div>

        {
          currentstate==="Sign Up"?
        <p className='select_page'>already have an account? <span onClick={()=>setCurrentstate("Login")}>login here</span></p>
        :<p className='select_page'>create a new account? <span onClick={()=>setCurrentstate("Sign Up")}>signup here</span></p>
        }

      </form>
    </div>
  )
}

export default Login_popup