import React, { useContext, useEffect } from 'react';
import './Food_Display.css';
import { Store_Context } from '../../context/Store_Context';
import Food_item from '../Food_item/Food_item';

// Food_Display component to render food items based on selected category
const Food_Display = ({ category }) => {
    const { food_list } = useContext(Store_Context); // Access food_list from context

    return (
        <div>
            <div className="food_display" id="food_display">
                <h2>Top Dishes Near You</h2>
                <div className="food_display_list">
                    {food_list.map((item) => {
                        // Check if the item's category matches the selected category
                        if (category === "All" || category === item.category) {
                            return (
                                <Food_item
                                    key={item._id} // Use _id as the unique key
                                    id={item._id} // Pass _id as id prop
                                    name={item.name}
                                    description={item.description}
                                    price={item.price}
                                    image={item.image}
                                />
                            );
                        }
                        return null; // Return null if the category doesn't match
                    })}
                </div>
            </div>
        </div>
    );
}

export default Food_Display;
