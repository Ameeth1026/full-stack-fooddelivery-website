import React, { useContext } from 'react';
import { assets } from '../../assets/assets';
import './Food_item.css';
import { Store_Context } from '../../context/Store_Context';

// Food_item component to display individual food items
const Food_item = ({ id, name, price, description, image }) => {
    const { cartItems, addToCart, removeFromCart, url } = useContext(Store_Context); // Access context values

    const itemCount = cartItems?.[id] || 0; // Use optional chaining to avoid TypeError

    return (
        <div className="food_item">
            <div className="food_item_img_container">
                <img src={`${url}/images/${image}`} className='food_item_image' alt={name} />

                {itemCount === 0 ? (
                    <img 
                        className='add_first' 
                        onClick={() => addToCart(id)} 
                        src={assets.add_icon_white} 
                        alt='Add to Cart' 
                    />
                ) : (
                    <div className="food-item-counter">
                        <img 
                            onClick={() => removeFromCart(id)} 
                            src={assets.remove_icon_red} 
                            alt="Remove from Cart" 
                        />
                        <p>{itemCount}</p>
                        <img 
                            onClick={() => addToCart(id)} 
                            src={assets.add_icon_green} 
                            alt="Add More" 
                        />
                    </div>
                )}
            </div>
            <div className="food_item_info">
                <div className="food_item_name_rating">
                    <p className='food_item_desc'>{name}</p>
                    <img src={assets.rating_starts} alt="Rating" />
                </div>
                <p className="food_item_desc">{description}</p>
                <p className='price'>₹ {price}</p>
            </div>
        </div>
    );
};

export default Food_item;
