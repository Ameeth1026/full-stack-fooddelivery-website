the node module package was removed you need to install the packages 

use the terminal and use command "npm install"

then "npm run dev"

that's all 